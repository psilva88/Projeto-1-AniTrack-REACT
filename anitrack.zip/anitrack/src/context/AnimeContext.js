import { createContext, useState, useContext } from "react";

export const AnimeContext = createContext();

const animesIniciais = [
  { id: 1, nome: "Attack on Titan", totalEps: 87, assistidos: 87, favorito: true, status: "Finalizado" },
  { id: 2, nome: "Demon Slayer", totalEps: 44, assistidos: 26, favorito: true, status: "Assistindo" },
  { id: 3, nome: "Jujutsu Kaisen", totalEps: 48, assistidos: 12, favorito: false, status: "Assistindo" },
  { id: 4, nome: "Spy x Family", totalEps: 25, assistidos: 25, favorito: false, status: "Finalizado" },
  { id: 5, nome: "Vinland Saga", totalEps: 48, assistidos: 0, favorito: false, status: "Pausado" },
];

const hoje = new Date().toLocaleDateString("pt-BR");

const historicoInicial = [
  { id: 1, acao: "Adicionou", anime: "Attack on Titan", data: "10/05/2025" },
  { id: 2, acao: "Finalizou", anime: "Demon Slayer (Season 1)", data: "08/05/2025" },
  { id: 3, acao: "Favoritou", anime: "Jujutsu Kaisen", data: "05/05/2025" },
  { id: 4, acao: "Adicionou", anime: "Spy x Family", data: "01/05/2025" },
  { id: 5, acao: "Finalizou", anime: "Death Note", data: "25/04/2025" },
];

export function AnimeProvider({ children }) {
  const [animes, setAnimes] = useState(animesIniciais);
  const [historico, setHistorico] = useState(historicoInicial);

  function addHistorico(acao, anime) {
    setHistorico((prev) => [
      { id: Date.now(), acao, anime, data: hoje },
      ...prev,
    ]);
  }

  function addAnime(novoAnime) {
    setAnimes((prev) => [novoAnime, ...prev]);
    addHistorico("Adicionou", novoAnime.nome);
  }

  function removeAnime(id) {
    setAnimes((prev) => prev.filter((a) => a.id !== id));
  }

  function toggleFavorito(id) {
    setAnimes((prev) =>
      prev.map((a) => {
        if (a.id === id) {
          if (!a.favorito) addHistorico("Favoritou", a.nome);
          return { ...a, favorito: !a.favorito };
        }
        return a;
      })
    );
  }

  // Estatísticas calculadas em tempo real com base na lista atual
  const stats = {
    total: animes.length,
    episodiosAssistidos: animes.reduce((sum, a) => sum + a.assistidos, 0),
    finalizados: animes.filter((a) => a.status === "Finalizado").length,
    favoritos: animes.filter((a) => a.favorito).length,
  };

  return (
    <AnimeContext.Provider
      value={{ animes, historico, stats, addAnime, removeAnime, toggleFavorito }}
    >
      {children}
    </AnimeContext.Provider>
  );
}

export function useAnime() {
  return useContext(AnimeContext);
}
