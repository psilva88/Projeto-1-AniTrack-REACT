import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../context/ThemeContext";
import { useResponsive } from "../hooks/useResponsive";

const SunIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>;
const MoonIcon = () => <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>;
const HomeIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>;
const DashIcon = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
const MenuIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>;
const XIcon = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;

function Navbar() {
  const { theme, darkMode, toggleTheme } = useTheme();
  const { isMobile } = useResponsive();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  const isActive = (path) =>
    location.pathname === path || location.pathname.startsWith(path + "/");

  const navHeight = isMobile ? "68px" : "92px";
  const logoHeight = isMobile ? "54px" : "84px";

  const linkStyle = (active) => ({
    color: active ? "#a78bfa" : "#64748b",
    textDecoration: "none",
    padding: isMobile ? "12px 16px" : "8px 16px",
    borderRadius: "8px",
    fontSize: "14px",
    fontWeight: active ? "600" : "400",
    fontFamily: "'Inter', sans-serif",
    background: active ? "rgba(124,58,237,0.12)" : "transparent",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  });

  return (
    <>
      <nav style={{
        background: theme.bgNav,
        padding: isMobile ? "0 20px" : "0 40px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        height: navHeight,
        position: "sticky",
        top: 0,
        zIndex: 100,
        boxShadow: "0 1px 0 rgba(255,255,255,0.05)",
      }}>
        <Link to="/" style={{ display: "flex", alignItems: "center", textDecoration: "none" }} onClick={() => setMenuOpen(false)}>
          <img src="/images/logo.png" alt="AniTrack" style={{ height: logoHeight, width: "auto", mixBlendMode: "screen", filter: "brightness(1.1)" }} />
        </Link>

        {/* Desktop links */}
        {!isMobile && (
          <div style={{ display: "flex", gap: "4px", alignItems: "center" }}>
            <Link to="/" style={linkStyle(location.pathname === "/")}><HomeIcon /> Home</Link>
            <Link to="/dashboard/minha-lista" style={linkStyle(isActive("/dashboard"))}><DashIcon /> Dashboard</Link>
            <button onClick={toggleTheme} style={{ background: "rgba(124,58,237,0.12)", border: "1px solid rgba(124,58,237,0.2)", color: "#a78bfa", padding: "8px 16px", borderRadius: "20px", cursor: "pointer", fontSize: "13px", fontWeight: "500", fontFamily: "'Inter', sans-serif", display: "flex", alignItems: "center", gap: "6px", marginLeft: "8px" }}>
              {darkMode ? <SunIcon /> : <MoonIcon />} {darkMode ? "Light" : "Dark"}
            </button>
          </div>
        )}

        {/* Mobile: hamburger */}
        {isMobile && (
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <button onClick={toggleTheme} style={{ background: "rgba(124,58,237,0.12)", border: "1px solid rgba(124,58,237,0.2)", color: "#a78bfa", padding: "7px 10px", borderRadius: "20px", cursor: "pointer", display: "flex", alignItems: "center", gap: "5px", fontSize: "12px" }}>
              {darkMode ? <SunIcon /> : <MoonIcon />}
            </button>
            <button onClick={() => setMenuOpen(!menuOpen)} style={{ background: "transparent", border: "none", color: "#a78bfa", cursor: "pointer", display: "flex", alignItems: "center", padding: "4px" }}>
              {menuOpen ? <XIcon /> : <MenuIcon />}
            </button>
          </div>
        )}
      </nav>

      {/* Mobile menu dropdown */}
      {isMobile && menuOpen && (
        <div style={{ background: theme.bgNav, borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "8px 16px 16px", position: "sticky", top: navHeight, zIndex: 99, display: "flex", flexDirection: "column", gap: "4px" }}>
          <Link to="/" style={linkStyle(location.pathname === "/")} onClick={() => setMenuOpen(false)}><HomeIcon /> Home</Link>
          <Link to="/dashboard/minha-lista" style={linkStyle(isActive("/dashboard"))} onClick={() => setMenuOpen(false)}><DashIcon /> Dashboard</Link>
        </div>
      )}
    </>
  );
}

export default Navbar;
