import { useState } from "react";
import { useTheme } from "../context/ThemeContext";
import { useAnime } from "../context/AnimeContext";
import { useResponsive } from "../hooks/useResponsive";

const FILTROS = [
  { key: "Todos", label: "Todos" },
  { key: "Assistindo", label: "Assistindo" },
  { key: "Pausado", label: "Pausado" },
  { key: "Finalizado", label: "Finalizado" },
  { key: "Favoritos", label: "Favoritos" },
];

const StarIcon = ({ filled }) => <svg width="17" height="17" viewBox="0 0 24 24" fill={filled ? "#f59e0b" : "none"} stroke={filled ? "#f59e0b" : "#475569"} strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>;
const TrashIcon = () => <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>;
const PlusIcon = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;

function MinhaLista() {
  const { theme } = useTheme();
  const { animes, addAnime, removeAnime, toggleFavorito } = useAnime();
  const { isMobile } = useResponsive();
  const [filtro, setFiltro] = useState("Todos");
  const [form, setForm] = useState({ nome: "", totalEps: "", assistidos: "", status: "Assistindo" });
  const [erros, setErros] = useState({});

  const font = "'Inter', sans-serif";
  const fontDisplay = "'Plus Jakarta Sans', sans-serif";

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (erros[name]) setErros((p) => ({ ...p, [name]: "" }));
  }

  function validar() {
    const e = {};
    if (!form.nome.trim()) e.nome = "Nome obrigatório.";
    if (!form.totalEps || Number(form.totalEps) <= 0) e.totalEps = "Valor inválido.";
    if (form.assistidos === "" || Number(form.assistidos) < 0) e.assistidos = "Valor inválido.";
    if (Number(form.assistidos) > Number(form.totalEps)) e.assistidos = "Maior que o total.";
    return e;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const novosErros = validar();
    if (Object.keys(novosErros).length > 0) { setErros(novosErros); return; }
    addAnime({ id: Date.now(), nome: form.nome.trim(), totalEps: Number(form.totalEps), assistidos: Number(form.assistidos), favorito: false, status: form.status });
    setForm({ nome: "", totalEps: "", assistidos: "", status: "Assistindo" });
    setErros({});
  }

  const listaFiltrada = filtro === "Todos" ? animes : filtro === "Favoritos" ? animes.filter((a) => a.favorito) : animes.filter((a) => a.status === filtro);

  const statusColor = (s) => {
    if (s === "Finalizado") return { bg: theme.success, text: theme.successText };
    if (s === "Assistindo") return { bg: theme.info, text: theme.infoText };
    if (s === "Pausado") return { bg: theme.warning, text: theme.warningText };
    return { bg: theme.tagBg, text: theme.tagText };
  };

  const card = { background: theme.bgCard, border: `1px solid ${theme.border}`, borderRadius: "14px", padding: isMobile ? "18px 16px" : "24px", marginBottom: "18px" };
  const input = { width: "100%", padding: "10px 13px", borderRadius: "8px", border: `1px solid ${theme.inputBorder}`, background: theme.inputBg, color: theme.text, fontSize: "14px", fontFamily: font, outline: "none", boxSizing: "border-box" };
  const lbl = { color: theme.textMuted, fontSize: "11px", fontWeight: "600", letterSpacing: "0.06em", textTransform: "uppercase", marginBottom: "6px", display: "block", fontFamily: font };

  return (
    <div>
      <h2 style={{ color: theme.text, fontSize: isMobile ? "20px" : "22px", fontWeight: "700", fontFamily: fontDisplay, marginBottom: "4px" }}>Minha Lista</h2>
      <p style={{ color: theme.textMuted, fontSize: "14px", fontFamily: font, marginBottom: "20px" }}>Gerencie seus animes, episódios e favoritos.</p>

      {/* Form — 1 coluna no mobile, 4 colunas no desktop */}
      <div style={card}>
        <p style={{ color: theme.text, fontSize: "14px", fontWeight: "600", fontFamily: font, marginBottom: "16px" }}>Adicionar novo anime</p>
        <form onSubmit={handleSubmit}>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 110px 110px 150px", gap: "12px" }}>
            <div>
              <label style={lbl}>Nome do anime *</label>
              <input style={input} name="nome" value={form.nome} onChange={handleChange} placeholder="Ex: Naruto Shippuden" />
              {erros.nome && <p style={{ color: "#ef4444", fontSize: "11px", marginTop: "4px" }}>{erros.nome}</p>}
            </div>
            <div>
              <label style={lbl}>Total eps *</label>
              <input style={input} name="totalEps" type="number" min="1" value={form.totalEps} onChange={handleChange} placeholder="220" />
              {erros.totalEps && <p style={{ color: "#ef4444", fontSize: "11px", marginTop: "4px" }}>{erros.totalEps}</p>}
            </div>
            <div>
              <label style={lbl}>Assistidos *</label>
              <input style={input} name="assistidos" type="number" min="0" value={form.assistidos} onChange={handleChange} placeholder="0" />
              {erros.assistidos && <p style={{ color: "#ef4444", fontSize: "11px", marginTop: "4px" }}>{erros.assistidos}</p>}
            </div>
            <div>
              <label style={lbl}>Status</label>
              <select style={input} name="status" value={form.status} onChange={handleChange}>
                <option value="Assistindo">Assistindo</option>
                <option value="Pausado">Pausado</option>
                <option value="Finalizado">Finalizado</option>
              </select>
            </div>
          </div>
          <button type="submit" style={{ display: "inline-flex", alignItems: "center", gap: "7px", background: "#7c3aed", color: "#fff", border: "none", padding: "10px 22px", borderRadius: "8px", cursor: "pointer", fontWeight: "600", fontSize: "14px", fontFamily: font, marginTop: "16px", width: isMobile ? "100%" : "auto", justifyContent: "center" }}>
            <PlusIcon /> Adicionar à lista
          </button>
        </form>
      </div>

      {/* Lista */}
      <div style={card}>
        <p style={{ color: theme.text, fontSize: "14px", fontWeight: "600", fontFamily: font, marginBottom: "14px" }}>
          Meus Animes <span style={{ color: theme.textMuted, fontWeight: "400" }}>({listaFiltrada.length} título{listaFiltrada.length !== 1 ? "s" : ""})</span>
        </p>
        <div style={{ display: "flex", gap: "6px", marginBottom: "18px", flexWrap: "wrap" }}>
          {FILTROS.map(({ key, label }) => (
            <button key={key} onClick={() => setFiltro(key)} style={{ padding: "6px 14px", borderRadius: "20px", border: "none", cursor: "pointer", fontSize: "13px", fontWeight: filtro === key ? "600" : "400", fontFamily: font, background: filtro === key ? (key === "Favoritos" ? "#92400e" : "#7c3aed") : theme.tagBg, color: filtro === key ? "#fff" : theme.tagText, display: "flex", alignItems: "center", gap: "4px" }}>
              {key === "Favoritos" && <svg width="11" height="11" viewBox="0 0 24 24" fill={filtro === key ? "#fff" : "#f59e0b"} stroke={filtro === key ? "#fff" : "#f59e0b"} strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>}
              {label}
            </button>
          ))}
        </div>

        {listaFiltrada.length === 0 ? (
          <p style={{ color: theme.textMuted, textAlign: "center", padding: "32px 0", fontSize: "14px", fontFamily: font }}>
            {filtro === "Favoritos" ? "Nenhum anime favoritado ainda." : "Nenhum anime nessa categoria ainda."}
          </p>
        ) : listaFiltrada.map((anime) => {
          const pct = anime.totalEps > 0 ? Math.round((anime.assistidos / anime.totalEps) * 100) : 0;
          const sc = statusColor(anime.status);
          return (
            <div key={anime.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 0", borderBottom: `1px solid ${theme.border}`, gap: "10px", flexWrap: isMobile ? "wrap" : "nowrap" }}>
              <div style={{ flex: 1, minWidth: isMobile ? "100%" : "160px" }}>
                <p style={{ color: theme.text, fontWeight: "600", fontSize: "14px", fontFamily: fontDisplay }}>{anime.nome}</p>
                <p style={{ color: theme.textMuted, fontSize: "12px", marginTop: "3px", fontFamily: font }}>{anime.assistidos}/{anime.totalEps} eps · {pct}%</p>
                <div style={{ width: isMobile ? "100%" : "110px", height: "3px", background: theme.border, borderRadius: "2px", overflow: "hidden", marginTop: "6px" }}>
                  <div style={{ height: "100%", width: `${pct}%`, background: pct === 100 ? "#10b981" : "#7c3aed", borderRadius: "2px" }} />
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginLeft: isMobile ? "auto" : "0" }}>
                <span style={{ fontSize: "11px", padding: "3px 10px", borderRadius: "20px", fontWeight: "600", fontFamily: font, background: sc.bg, color: sc.text, whiteSpace: "nowrap" }}>{anime.status}</span>
                <button style={{ background: "none", border: "none", cursor: "pointer", display: "flex", padding: "2px" }} onClick={() => toggleFavorito(anime.id)}><StarIcon filled={anime.favorito} /></button>
                <button style={{ display: "inline-flex", alignItems: "center", gap: "4px", background: theme.danger, color: theme.dangerText, border: "none", borderRadius: "7px", padding: "6px 10px", cursor: "pointer", fontSize: "12px", fontWeight: "600", fontFamily: font }} onClick={() => removeAnime(anime.id)}><TrashIcon /> Remover</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default MinhaLista;
