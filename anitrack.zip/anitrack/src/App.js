import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "./context/ThemeContext";
import { AnimeProvider } from "./context/AnimeContext";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import MinhaLista from "./pages/MinhaLista";
import Perfil from "./pages/Perfil";
import NotFound from "./pages/NotFound";

function App() {
  return (
    // ThemeProvider e AnimeProvider envolvem toda a aplicação (Context API - Encontro 7)
    <ThemeProvider>
      <AnimeProvider>
        <BrowserRouter>
          <div style={{ display: "flex", flexDirection: "column", minHeight: "100vh" }}>
            <Navbar />
            <div style={{ flex: 1 }}>
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/dashboard" element={<Dashboard />}>
                  <Route path="minha-lista" element={<MinhaLista />} />
                  <Route path="perfil" element={<Perfil />} />
                </Route>
                <Route path="*" element={<NotFound />} />
              </Routes>
            </div>
            <Footer />
          </div>
        </BrowserRouter>
      </AnimeProvider>
    </ThemeProvider>
  );
}

export default App;
